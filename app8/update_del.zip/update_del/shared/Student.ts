export class Student{
    studentId:number;
    studentName:string;
    studentPassword:string;
}